/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computermain;

/**
 *
 * @author USER
 */
public class Desktop {
    private String formFactor;
    private String brand; 
    private int storageSize;
    private Monitor monitor;
    
    public Desktop()
    {
    formFactor = "Microtower";
    brand = "HP";
    storageSize = 512;
    }
     
    public Desktop(Monitor monitor)
    {
    formFactor = "Microtower";
    brand = "HP";
    storageSize = 512;
    this.monitor = monitor;
    }
    
    public String getformFactor()
    {
    return formFactor;
    }
    
    public String getbrand()
    {
    return brand;
    }
    
    public int getstorageSize()
    {
    return storageSize;
    }
    
    public Monitor getmonitor()
    {
    return monitor;
    }
    
    public void setformFactor(String formFactor)
    {
    this.formFactor = formFactor;
    }
    
    public void setbrand(String brand)
    {
    this.brand = brand;
    }
    
    public void setstorageSize(int storageSize)
    {
    this.storageSize = storageSize;
    }
    
    public void setmonitor (Monitor monitor)
    {
    this.monitor = monitor;
    } 
}
