/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computermain;

/**
 *
 * @author USER
 */
public class Laptop {
    private String type;
    private String brand; 
    private double screenSize;
    private int memorySize; 
    private Monitor monitor;
   
    
    public Laptop (String type, String brand, double screenSize)
    {
        this.type = type;
        this.brand = brand;
        this.screenSize = screenSize;
        memorySize = 8;
        monitor = new Monitor();
    }
    
    public String gettype()
    {
        return type; 
    }
    
    public String getbrand()
    {
        return brand; 
    }
    
    public double getscreenSize()
    {
        return screenSize;
    }
    
    public int getmemorySize()
    {
        return memorySize; 
    }
    
    public Monitor getmonitor()
    {
        return monitor; 
    }
    
    public void settype(String type)
    {
        this.type = type; 
    }
    
    public void setbrand (String brand)
    {
        this.brand = brand; 
    }
    
    public void setscreenSize(double screenSize)
    {
        this.screenSize = screenSize; 
    }
    
    public void setmemorySize(int memorySize)
    {
        this.memorySize = memorySize;
    }
    
    public void setmonitor(Monitor monitor)
    {
        this.monitor = monitor;
    }
    
//    public void upgradeMemory()
//    {
//        setmemorySize(getmemorySize() + 8);
//    }
//    
//    public void downgradeMemory()
//    {
//        setmemorySize(getmemorySize() - 4);
//    }
}
