/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computermain;

/**
 *
 * @author USER
 */
public class Monitor {
        private int brightness;
    private double screenSize;
    
    public Monitor ()
    {
        brightness = 250;
        screenSize= 17;
    }
    
    public int getbrightness()
    {
        return brightness;
    }
    
    public double getscreenSize()
    {
        return screenSize;
    }
    
    public void setbrightness(int brightness)
    {
        this.brightness = brightness;
    }
    
    public void setscreenSize(double screenSize)
    {
        this.screenSize = screenSize;
    }
}
