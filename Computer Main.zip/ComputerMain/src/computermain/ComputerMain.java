/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computermain;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class ComputerMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Monitor mymonitor = new Monitor();
        Desktop mydesktop = new Desktop(mymonitor);
        Laptop mylaptop = new Laptop("Thinkpad", "Lenovo", 13.3);
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("THE INPUT MONITOR INFORMATION FOR DESKTOP");
        System.out.println("Please Enter Monitor Brightness: ");
        mydesktop.getmonitor().setbrightness(input.nextInt());
        System.out.println("Please Enter Monitor Screen Size: ");
        mydesktop.getmonitor().setscreenSize(input.nextDouble());
        
        System.out.println("\nTHE INPUT MONITOR INFORMATION FOR LAPTOP");
        System.out.println("Please Enter Monitor Brightness: ");
        mylaptop.getmonitor().setbrightness(input.nextInt());
        System.out.println("Please Enter Monitor Screen Size: ");
        mylaptop.getmonitor().setscreenSize(input.nextDouble());
        
         System.out.println("\nTHE OUTPUT INFORMATION FOR DESKTOP");
         System.out.println("The following are the information for DESKTOP");
         System.out.println("Desktop Brand: " + mydesktop.getbrand() + 
                 "|" + "Desktop Form Factor: " + mydesktop.getformFactor() + 
                 "|" + "Desktop Storage Size: " + mydesktop.getstorageSize() + 
                 "|" + "Desktop Screen Size: " + mydesktop.getmonitor().getscreenSize() + 
                 "|" + "Desktop Brightness: " + mydesktop.getmonitor().getbrightness());
         
         System.out.println("\nTHE OUTPUT INFORMATION FOR LAPTOP");
         System.out.println("The following are the information for LAPTOP");
         System.out.println("Laptop Brand: " + mylaptop.getbrand()+ 
                 "|" + "Laptop Type: " + mylaptop.gettype() + 
                 "|" + "Laptop Memory Size: " + mylaptop.getmemorySize() + 
                 "|" + "Laptop Screen Size: " + mylaptop.getmonitor().getscreenSize() + 
                 "|" + "Laptop Brightness: " + mylaptop.getmonitor().getbrightness());
         
         mydesktop = null;
         mylaptop = null;
         System.out.println("");
         System.out.println("Monitor Screen Size: " + mymonitor.getscreenSize());
    }
    
}
