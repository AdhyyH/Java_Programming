/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

/**
 *
 * @author USER
 */
public class Vehicle {
     private String type, transmission, powertrain;
    private int speed;
    
    //Constructor
    public Vehicle(String type, String transmission, String powertrain){
        this.type = type;
        this.transmission = transmission;
        this.powertrain = powertrain;
        speed = 60;
    }
    
    public void accelerate(){
        speed = speed + 10;
    }
    
    public void brake(){
        speed = speed - 5;
    }
    
    //Accessor
    public String getType(){
        return type;
    }
    
    public String getTransmission(){
        return transmission;
    }
    public String getPowertrain(){
        return powertrain;
    }
    
    public int getSpped(){
        return speed;
    }
    
    //Mutator    
    public void setType(String type){
        this.type = type;
    }
    
    public void setTransmission(String transmission){
        this.transmission = transmission;
    }
    
    public void setPowertrain(String powertrain){
        this.powertrain = powertrain;
    }
}


