/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

/**
 *
 * @author USER
 */
public class VehicleApp {

    public static void main(String[] args) {
        Vehicle car = new Vehicle("Car", "Manual", "Electric");
        
        car.accelerate();
        System.out.println("Accelerate: Current Speed = " + car.getSpped());
        
        car.brake();
        System.out.println("Brake: Current Speed = " + car.getSpped());
        
        System.out.println(car.getPowertrain() + " " + car.getType() + " with " + car.getTransmission() + " transmission");
        
    }

}
